//! RNS-aware key generation for CKKS
//!
//! This module provides key structures and generation functions that work
//! with RNS (Residue Number System) representation, enabling multi-prime CKKS.

use crate::clifford_fhe::params::CliffordFHEParams;
use crate::clifford_fhe::rns::{RnsPolynomial, rns_add, rns_multiply as rns_poly_multiply};
use rand::{thread_rng, Rng};
use rand_distr::{Distribution, Normal};

/// RNS-aware public key
#[derive(Clone, Debug)]
pub struct RnsPublicKey {
    /// First component (RNS polynomial)
    pub a: RnsPolynomial,
    /// Second component (RNS polynomial): b = a*s + e
    pub b: RnsPolynomial,
    /// Ring dimension
    pub n: usize,
}

/// RNS-aware secret key
#[derive(Clone, Debug)]
pub struct RnsSecretKey {
    /// Secret polynomial (RNS representation)
    /// This is a ternary polynomial: coefficients in {-1, 0, 1}
    pub coeffs: RnsPolynomial,
    /// Ring dimension
    pub n: usize,
}

/// RNS-aware evaluation key (for relinearization)
#[derive(Clone, Debug)]
pub struct RnsEvaluationKey {
    /// Relinearization keys (encryptions of powers of s)
    /// For simplicity, just store one key that encrypts s²
    pub relin_keys: Vec<(RnsPolynomial, RnsPolynomial)>,
    /// Ring dimension
    pub n: usize,
}

/// RNS-aware rotation key (for slot rotations)
#[derive(Clone, Debug)]
pub struct RnsRotationKey {
    /// Map from automorphism index to key pair
    pub keys: std::collections::HashMap<usize, (RnsPolynomial, RnsPolynomial)>,
    /// Ring dimension
    pub n: usize,
}

/// Generate RNS-CKKS keys
///
/// This generates a fresh secret key and derives the public key and evaluation key.
/// All keys are in RNS form, compatible with multi-prime CKKS operations.
///
/// # Key Generation Algorithm
/// 1. Sample secret s ← {-1, 0, 1}^N (ternary polynomial)
/// 2. Sample a ← R_Q uniformly (each prime independently)
/// 3. Sample error e ← χ (Gaussian, then convert to RNS)
/// 4. Compute b = a*s + e (all in RNS)
/// 5. Public key: (a, b)
///
/// # Returns
/// (PublicKey, SecretKey, EvaluationKey)
pub fn rns_keygen(params: &CliffordFHEParams) -> (RnsPublicKey, RnsSecretKey, RnsEvaluationKey) {
    let n = params.n;
    let primes = &params.moduli;
    let num_primes = primes.len();
    let mut rng = thread_rng();

    // 1. Sample secret key: ternary polynomial s ∈ {-1, 0, 1}^N
    let s_coeffs: Vec<i64> = (0..n)
        .map(|_| {
            let val: f64 = rng.gen();
            if val < 0.33 {
                -1
            } else if val < 0.66 {
                0
            } else {
                1
            }
        })
        .collect();

    // Convert to RNS (level 0 = all primes active)
    let s_rns = RnsPolynomial::from_coeffs(&s_coeffs, primes, n, 0);

    // 2. Sample uniform polynomial a
    // For each prime, sample uniformly from [0, q_i)
    let mut a_rns_coeffs = vec![vec![0i64; num_primes]; n];
    for i in 0..n {
        for (j, &qj) in primes.iter().enumerate() {
            a_rns_coeffs[i][j] = rng.gen_range(0..qj);
        }
    }
    let a_rns = RnsPolynomial::new(a_rns_coeffs, n, 0);

    // 3. Sample error from Gaussian distribution
    let normal = Normal::new(0.0, params.error_std).unwrap();
    let e_coeffs: Vec<i64> = (0..n).map(|_| normal.sample(&mut rng).round() as i64).collect();
    let e_rns = RnsPolynomial::from_coeffs(&e_coeffs, primes, n, 0);

    // 4. Compute b = a*s + e (in RNS)
    let polynomial_multiply_ntt = |a: &[i64], b: &[i64], q: i64, n: usize| -> Vec<i64> {
        // Temporary naive implementation with i128 to avoid overflow
        let mut result = vec![0i128; n];
        let q128 = q as i128;

        for i in 0..n {
            for j in 0..n {
                let idx = i + j;
                let prod = (a[i] as i128) * (b[j] as i128) % q128;
                if idx < n {
                    result[idx] = (result[idx] + prod) % q128;
                } else {
                    // x^n = -1 reduction (negacyclic)
                    let wrapped_idx = idx % n;
                    result[wrapped_idx] = (result[wrapped_idx] - prod) % q128;
                }
            }
        }
        result.iter().map(|&x| ((x % q128 + q128) % q128) as i64).collect()
    };

    let a_times_s = rns_poly_multiply(&a_rns, &s_rns, primes, polynomial_multiply_ntt);
    let b_rns = rns_add(&a_times_s, &e_rns, primes);

    // 5. Create public key
    let pk = RnsPublicKey {
        a: a_rns,
        b: b_rns,
        n,
    };

    // 6. Create secret key
    let sk = RnsSecretKey {
        coeffs: s_rns.clone(),
        n,
    };

    // 7. Generate evaluation key (for relinearization)
    // This encrypts s² under the public key
    let evk = generate_rns_evaluation_key(&s_rns, &pk, params);

    (pk, sk, evk)
}

/// Generate RNS evaluation key for relinearization
///
/// Creates a key that allows converting degree-2 ciphertexts back to degree-1.
/// This is an encryption of s² under the public key.
fn generate_rns_evaluation_key(
    sk: &RnsPolynomial,
    pk: &RnsPublicKey,
    params: &CliffordFHEParams,
) -> RnsEvaluationKey {
    let n = params.n;
    let primes = &params.moduli;
    let mut rng = thread_rng();

    // Compute s² (secret squared)
    let polynomial_multiply_ntt = |a: &[i64], b: &[i64], q: i64, n: usize| -> Vec<i64> {
        let mut result = vec![0i128; n];
        let q128 = q as i128;
        for i in 0..n {
            for j in 0..n {
                let idx = i + j;
                let prod = (a[i] as i128) * (b[j] as i128) % q128;
                if idx < n {
                    result[idx] = (result[idx] + prod) % q128;
                } else {
                    let wrapped_idx = idx % n;
                    result[wrapped_idx] = (result[wrapped_idx] - prod) % q128;
                }
            }
        }
        result.iter().map(|&x| ((x % q128 + q128) % q128) as i64).collect()
    };

    let s_squared = rns_poly_multiply(sk, sk, primes, polynomial_multiply_ntt);

    // Generate evaluation key to match decrypt formula: m' = c0 - c1*s
    //
    // For relinearization to work correctly:
    // We need: c0_new + c1_new*(-s) ≈ d0 + d1*(-s) + d2*s²
    //
    // EVK encrypts s² in a form compatible with key-switching:
    // evk1 = a_k (fresh uniform)
    // evk0 = -a_k*s + e_k + s²
    //
    // Then: d2*evk0 + (d2*evk1)*(-s) = d2*(-a_k*s + e_k + s²) - d2*a_k*s
    //                                 = d2*s² + noise

    // Sample fresh uniform a_k for this key
    let mut a_k_rns_coeffs = vec![vec![0i64; primes.len()]; n];
    for i in 0..n {
        for (j, &qj) in primes.iter().enumerate() {
            a_k_rns_coeffs[i][j] = rng.gen_range(0..qj);
        }
    }
    let a_k = RnsPolynomial::new(a_k_rns_coeffs, n, 0);

    // Sample error
    let normal = Normal::new(0.0, params.error_std).unwrap();
    let e_k_coeffs: Vec<i64> = (0..n).map(|_| normal.sample(&mut rng).round() as i64).collect();
    let e_k = RnsPolynomial::from_coeffs(&e_k_coeffs, primes, n, 0);

    // Compute: evk0 = a_k*s + e_k + s² (POSITIVE a_k*s for our decrypt convention)
    //
    // With decrypt: m' = c0 - c1*s
    // And relinearization: c0 = d0 + d2*evk0, c1 = d1 + d2*evk1
    // We need: evk0 - evk1*s = s²
    // Therefore: evk0 = s² + evk1*s = s² + a_k*s
    let a_k_s = rns_poly_multiply(&a_k, sk, primes, polynomial_multiply_ntt);

    let a_k_s_plus_e = rns_add(&a_k_s, &e_k, primes);
    let evk0 = rns_add(&a_k_s_plus_e, &s_squared, primes);

    // evk1 = a_k
    let evk1 = a_k;

    RnsEvaluationKey {
        relin_keys: vec![(evk0, evk1)],
        n,
    }
}

/// Generate RNS rotation keys for given rotation amounts
///
/// For each rotation r, generates a key-switching key that enables
/// rotating CKKS slots by r positions.
pub fn rns_generate_rotation_keys(
    sk: &RnsSecretKey,
    pk: &RnsPublicKey,
    rotations: &[isize],
    params: &CliffordFHEParams,
) -> RnsRotationKey {
    use crate::clifford_fhe::automorphisms::rotation_to_automorphism;
    use std::collections::HashMap;

    let mut keys = HashMap::new();

    for &r in rotations {
        // Convert rotation to automorphism index
        let k = rotation_to_automorphism(r, params.n);

        // Generate key-switching key for this automorphism
        // This is similar to evaluation key generation but for σ_k(s)
        // For simplicity, we'll skip the full implementation for now
        // and just store placeholder keys

        // TODO: Implement proper rotation key generation
        // For now, just clone the evaluation key structure as placeholder
        let dummy_key = (sk.coeffs.clone(), sk.coeffs.clone());
        keys.insert(k, dummy_key);
    }

    RnsRotationKey {
        keys,
        n: params.n,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rns_keygen() {
        let params = CliffordFHEParams::new_rns_mult();
        let (_pk, _sk, _evk) = rns_keygen(&params);
        // If this doesn't panic, key generation works!
    }
}
