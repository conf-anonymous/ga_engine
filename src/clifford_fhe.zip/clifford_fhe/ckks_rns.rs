//! RNS-CKKS encryption scheme for Clifford algebra
//!
//! This is the RNS (Residue Number System) version of CKKS that enables
//! proper homomorphic multiplication with rescaling.
//!
//! Key differences from single-modulus CKKS:
//! - Coefficients stored as RNS tuples instead of single i64
//! - Rescaling drops a prime from the modulus chain
//! - Supports larger effective moduli (Q = q₀ · q₁ · ... can be 2^200+)

use crate::clifford_fhe::keys::{EvaluationKey, PublicKey, SecretKey}; // Old single-modulus keys
use crate::clifford_fhe::keys_rns::{RnsPublicKey, RnsSecretKey, RnsEvaluationKey}; // New RNS keys
use crate::clifford_fhe::params::CliffordFHEParams;
use crate::clifford_fhe::rns::{RnsPolynomial, rns_add, rns_sub, rns_multiply as rns_poly_multiply, rns_rescale_exact, precompute_rescale_inv};

/// Helper function for polynomial multiplication modulo q with negacyclic reduction
fn polynomial_multiply_ntt(a: &[i64], b: &[i64], q: i64, n: usize) -> Vec<i64> {
    // Temporary naive implementation with i128 to avoid overflow
    // TODO: Use actual NTT for efficiency
    let mut result = vec![0i128; n];
    let q128 = q as i128;

    for i in 0..n {
        for j in 0..n {
            let idx = i + j;
            let prod = (a[i] as i128) * (b[j] as i128) % q128;
            if idx < n {
                result[idx] = (result[idx] + prod) % q128;
            } else {
                // x^n = -1 reduction (negacyclic)
                let wrapped_idx = idx % n;
                result[wrapped_idx] = (result[wrapped_idx] - prod) % q128;
            }
        }
    }

    result.iter().map(|&x| ((x % q128 + q128) % q128) as i64).collect()
}

/// RNS-CKKS plaintext (polynomial in RNS representation)
#[derive(Debug, Clone)]
pub struct RnsPlaintext {
    /// Polynomial coefficients in RNS form
    pub coeffs: RnsPolynomial,
    /// Scaling factor used for encoding
    pub scale: f64,
    /// Ring dimension
    pub n: usize,
}

impl RnsPlaintext {
    /// Create plaintext from RNS polynomial
    pub fn new(coeffs: RnsPolynomial, scale: f64) -> Self {
        let n = coeffs.n;
        Self { coeffs, scale, n }
    }

    /// Create plaintext from regular coefficients
    pub fn from_coeffs(coeffs: Vec<i64>, scale: f64, primes: &[i64], level: usize) -> Self {
        let n = coeffs.len();
        let rns_coeffs = RnsPolynomial::from_coeffs(&coeffs, primes, n, level);
        Self::new(rns_coeffs, scale)
    }

    /// Convert to regular coefficients using CRT (full reconstruction)
    ///
    /// WARNING: This can overflow if Q = ∏qᵢ > i64_MAX!
    /// Use to_coeffs_single_prime() instead for CKKS decoding.
    pub fn to_coeffs(&self, primes: &[i64]) -> Vec<i64> {
        self.coeffs.to_coeffs(primes)
    }

    /// Convert to regular coefficients using single prime (recommended for CKKS)
    ///
    /// Extracts coefficients modulo the first prime (largest/base prime).
    /// This avoids CRT overflow and is sufficient for CKKS decoding since
    /// message + noise << any single prime.
    ///
    /// # Arguments
    /// * `primes` - Prime chain (will use first prime)
    pub fn to_coeffs_single_prime(&self, primes: &[i64]) -> Vec<i64> {
        let prime_idx = 0; // Use first prime (largest, most precision)
        let prime_value = primes[prime_idx];
        self.coeffs.to_coeffs_single_prime(prime_idx, prime_value)
    }
}

/// RNS-CKKS ciphertext
///
/// A ciphertext is a pair (c0, c1) of RNS polynomials in R_q
/// Decryption: m ≈ c0 + c1*s (mod Q) where Q = q₀ · q₁ · ...
#[derive(Debug, Clone)]
pub struct RnsCiphertext {
    /// First component (RNS polynomial)
    pub c0: RnsPolynomial,
    /// Second component (RNS polynomial)
    pub c1: RnsPolynomial,
    /// Current level (determines which primes are active)
    /// Level 0: all primes [q₀, q₁, q₂, ...]
    /// Level 1: dropped last prime [q₀, q₁, ...]
    pub level: usize,
    /// Scaling factor (carries through homomorphic operations)
    pub scale: f64,
    /// Ring dimension
    pub n: usize,
}

impl RnsCiphertext {
    /// Create new RNS ciphertext
    pub fn new(c0: RnsPolynomial, c1: RnsPolynomial, level: usize, scale: f64) -> Self {
        let n = c0.n;
        assert_eq!(c1.n, n, "Ciphertext components must have same length");
        assert_eq!(c0.level, level, "c0 level mismatch");
        assert_eq!(c1.level, level, "c1 level mismatch");
        Self {
            c0,
            c1,
            level,
            scale,
            n,
        }
    }
}

/// Encrypt plaintext using public key (RNS version)
///
/// RNS-CKKS encryption:
/// 1. Sample random r, e0, e1 from error distribution
/// 2. Convert to RNS representation
/// 3. Compute (all in RNS):
///    c0 = b*r + e0 + m
///    c1 = a*r + e1
///
/// # Arguments
/// * `pk` - RNS public key
/// * `pt` - Plaintext in RNS form
/// * `params` - CKKS parameters with modulus chain
pub fn rns_encrypt(pk: &RnsPublicKey, pt: &RnsPlaintext, params: &CliffordFHEParams) -> RnsCiphertext {
    use rand::{thread_rng, Rng};
    use rand_distr::{Distribution, Normal};

    let n = params.n;
    let primes = &params.moduli;
    let num_primes = primes.len();
    let mut rng = thread_rng();

    // Sample ternary random polynomial r ∈ {-1, 0, 1}^n
    let r: Vec<i64> = (0..n)
        .map(|_| {
            let val: f64 = rng.gen();
            if val < 0.33 {
                -1
            } else if val < 0.66 {
                0
            } else {
                1
            }
        })
        .collect();

    // Sample errors e0, e1 from Gaussian distribution
    let normal = Normal::new(0.0, params.error_std).unwrap();
    let e0: Vec<i64> = (0..n).map(|_| normal.sample(&mut rng).round() as i64).collect();
    let e1: Vec<i64> = (0..n).map(|_| normal.sample(&mut rng).round() as i64).collect();

    // Convert to RNS
    let r_rns = RnsPolynomial::from_coeffs(&r, primes, n, 0);
    let e0_rns = RnsPolynomial::from_coeffs(&e0, primes, n, 0);
    let e1_rns = RnsPolynomial::from_coeffs(&e1, primes, n, 0);

    // Use RNS public key directly (already in RNS form!)
    // Compute b*r using RNS multiplication
    let br = rns_poly_multiply(&pk.b, &r_rns, primes, polynomial_multiply_ntt);

    // Compute a*r using RNS multiplication
    let ar = rns_poly_multiply(&pk.a, &r_rns, primes, polynomial_multiply_ntt);

    // c0 = b*r + e0 + m
    let c0_temp = rns_add(&br, &e0_rns, primes);
    let c0 = rns_add(&c0_temp, &pt.coeffs, primes);

    // c1 = a*r + e1
    let c1 = rns_add(&ar, &e1_rns, primes);

    RnsCiphertext::new(c0, c1, 0, pt.scale)
}

/// Decrypt ciphertext using secret key (RNS version)
///
/// RNS-CKKS decryption:
/// m' = c0 + c1*s (all in RNS, then convert back)
///
/// # Arguments
/// * `sk` - RNS secret key
/// * `ct` - Ciphertext in RNS form
/// * `params` - CKKS parameters
pub fn rns_decrypt(sk: &RnsSecretKey, ct: &RnsCiphertext, params: &CliffordFHEParams) -> RnsPlaintext {
    let n = ct.n;
    let primes = &params.moduli;
    let num_primes = primes.len() - ct.level; // Active primes at this level
    let active_primes = &primes[..num_primes];

    // Use RNS secret key directly
    // Note: If we've rescaled, the secret key needs to be at the same level
    // For level > 0, we need to use only the first num_primes components
    let sk_at_level = if ct.level > 0 {
        // Extract only active primes from secret key
        let mut rns_coeffs = vec![vec![0i64; num_primes]; n];
        for i in 0..n {
            for j in 0..num_primes {
                rns_coeffs[i][j] = sk.coeffs.rns_coeffs[i][j];
            }
        }
        RnsPolynomial::new(rns_coeffs, n, ct.level)
    } else {
        sk.coeffs.clone()
    };

    // Compute c1*s using RNS multiplication
    let c1s = rns_poly_multiply(&ct.c1, &sk_at_level, active_primes, polynomial_multiply_ntt);

    // m' = c0 - c1*s (because pk.b = a*s + e, so we need subtraction)
    let m_prime = rns_sub(&ct.c0, &c1s, active_primes);

    RnsPlaintext::new(m_prime, ct.scale)
}

/// Homomorphic addition (RNS version)
///
/// Simply add the RNS polynomials component-wise.
/// Scales must match!
pub fn rns_add_ciphertexts(
    ct1: &RnsCiphertext,
    ct2: &RnsCiphertext,
    params: &CliffordFHEParams,
) -> RnsCiphertext {
    assert_eq!(ct1.level, ct2.level, "Ciphertexts must be at same level");
    assert_eq!(ct1.n, ct2.n, "Ciphertexts must have same dimension");

    // TODO: Handle scale mismatch (need to rescale to match)
    // For now, require same scale
    assert!((ct1.scale - ct2.scale).abs() < 1e-6, "Scales must match (for now)");

    let primes = &params.moduli;
    let num_primes = primes.len() - ct1.level;
    let active_primes = &primes[..num_primes];

    let c0 = rns_add(&ct1.c0, &ct2.c0, active_primes);
    let c1 = rns_add(&ct1.c1, &ct2.c1, active_primes);

    RnsCiphertext::new(c0, c1, ct1.level, ct1.scale)
}

/// Homomorphic multiplication with rescaling (RNS version)
///
/// This is the KEY operation that requires RNS!
///
/// Steps:
/// 1. Multiply polynomials (tensored ciphertext): (c0, c1) ⊗ (d0, d1) = (c0d0, c0d1+c1d0, c1d1)
/// 2. Relinearize: convert degree-2 back to degree-1 using evaluation key
/// 3. **Rescale**: drop the last prime from the modulus chain
///
/// After rescaling:
/// - Level increases by 1 (one fewer prime)
/// - Scale divided by the dropped prime
/// - Coefficients properly normalized
pub fn rns_multiply_ciphertexts(
    ct1: &RnsCiphertext,
    ct2: &RnsCiphertext,
    evk: &RnsEvaluationKey,
    params: &CliffordFHEParams,
) -> RnsCiphertext {
    assert_eq!(ct1.level, ct2.level, "Ciphertexts must be at same level");
    assert_eq!(ct1.n, ct2.n, "Ciphertexts must have same dimension");

    let n = ct1.n;
    let primes = &params.moduli;
    let num_primes = primes.len() - ct1.level;
    let active_primes = &primes[..num_primes];

    // Step 1: Multiply ciphertexts (tensored product)
    // Degree-2 ciphertext: (d0, d1, d2) where m1 * m2 = d0 + d1*s + d2*s²
    let c0d0 = rns_poly_multiply(&ct1.c0, &ct2.c0, active_primes, polynomial_multiply_ntt);
    let c0d1 = rns_poly_multiply(&ct1.c0, &ct2.c1, active_primes, polynomial_multiply_ntt);
    let c1d0 = rns_poly_multiply(&ct1.c1, &ct2.c0, active_primes, polynomial_multiply_ntt);
    let c1d1 = rns_poly_multiply(&ct1.c1, &ct2.c1, active_primes, polynomial_multiply_ntt);

    // d1 = c0*d1 + c1*d0
    let d_mid = rns_add(&c0d1, &c1d0, active_primes);

    // Step 2: Relinearization (degree-2 → degree-1)
    let (new_c0, new_c1) = rns_relinearize_degree2(&c0d0, &d_mid, &c1d1, evk, active_primes, n);

    // Step 3: Exact rescaling with proper rounding
    // Precompute inverse constants for this level
    let inv_qlast = precompute_rescale_inv(active_primes);

    // Apply exact rescale: round(c / q_last)
    let rescaled_c0 = rns_rescale_exact(&new_c0, active_primes, &inv_qlast);
    let rescaled_c1 = rns_rescale_exact(&new_c1, active_primes, &inv_qlast);

    // New scale: (scale1 * scale2) / q_last
    // Since we designed scale ≈ q_last, the new scale ≈ original scale
    let q_last = active_primes[num_primes - 1];
    let new_scale = (ct1.scale * ct2.scale) / (q_last as f64);
    let new_level = ct1.level + 1;

    RnsCiphertext::new(rescaled_c0, rescaled_c1, new_level, new_scale)
}

/// Relinearize degree-2 ciphertext to degree-1 (RNS version)
///
/// Input: (d0, d1, d2) where m = d0 + d1*s + d2*s²
/// Output: (c0, c1) where m ≈ c0 + c1*s
///
/// Uses evaluation key which encrypts s²
fn rns_relinearize_degree2(
    d0: &RnsPolynomial,
    d1: &RnsPolynomial,
    d2: &RnsPolynomial,
    evk: &RnsEvaluationKey,
    primes: &[i64],
    _n: usize,
) -> (RnsPolynomial, RnsPolynomial) {
    // Use RNS evaluation key directly (already in RNS form!)
    let (evk0, evk1) = &evk.relin_keys[0];

    // d2 * evk0 (all in RNS)
    let d2_evk0 = rns_poly_multiply(d2, evk0, primes, polynomial_multiply_ntt);

    // d2 * evk1 (all in RNS)
    let d2_evk1 = rns_poly_multiply(d2, evk1, primes, polynomial_multiply_ntt);

    // c0 = d0 + d2*evk0
    let c0 = rns_add(d0, &d2_evk0, primes);

    // c1 = d1 + d2*evk1
    let c1 = rns_add(d1, &d2_evk1, primes);

    (c0, c1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rns_plaintext_conversion() {
        let coeffs = vec![123, 456, 789, -100];
        let scale = 1024.0;
        let primes = vec![1_099_511_627_689, 1_099_511_627_691];

        let pt = RnsPlaintext::from_coeffs(coeffs.clone(), scale, &primes, 0);
        let recovered = pt.to_coeffs(&primes);

        for i in 0..coeffs.len() {
            assert_eq!(coeffs[i], recovered[i]);
        }
    }
}
